@echo off
chcp 65001 >nul
cd /d "C:\Users\User\Desktop\JARVIS"

:: Запускаем свернутое окно, которое точно появится в панели задач
powershell -WindowStyle Hidden -Command "Start-Process cmd -ArgumentList '/c py -3.10 jarvis_main.py & pause' -WorkingDirectory 'C:\Users\User\Desktop\JARVIS' -WindowStyle Minimized"

exit