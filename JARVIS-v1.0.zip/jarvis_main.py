import os
import sys
import torch
import soundfile as sf
import sounddevice as sd
import numpy as np
import re
import ollama
import threading
import time
import speech_recognition as sr
import subprocess
import pygetwindow as gw
import pyautogui
import psutil
import random
import datetime

from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

# ==========================================
# КОНСТАНТА ДЛИНЫ ОТВЕТА
# ==========================================
MAX_WORDS = 50

# ==========================================
# БУФЕРЫ (заполнители)
# ==========================================
BUFFER_PHRASES = [
    "Секунду, проверяю.",
    "Одну минуту, анализирую.",
    "Подождите, сканирую данные.",
    "Проверяю информацию."
]

# ==========================================
# СЛОВА-ИСКЛЮЧЕНИЯ ДЛЯ КЭША
# ==========================================
NO_CACHE_WORDS = [
    "час", "врем", "минут", "секунд", "день", "число", "дата", 
    "погод", "температур", "дожд", "снег", "ветер", "солнц", 
    "громкост", "звук", "процент", 
    "процесс", "оператив", "память", "батаре", "заряд", "диск", "место",
    "компас", "направлен", "север", "юг", "запад", "восток",
    "анекдот", "шутк", "факт", "кубик", "монет"
]

# ==========================================
# ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ
# ==========================================
shutdown_blocked_until = 0  
shutdown_block_timer = None 
is_speaking = False

# ==========================================
# 1. ХАКИ ДЛЯ XTTS
# ==========================================
cache_path = os.path.expanduser("~/.cache/torch/hub/coqui-ai_TTS_main")
sys.path.append(cache_path)
sys.modules['mecab'] = type(sys)('mecab')
sys.modules['unidic_lite'] = type(sys)('unidic_lite')

try:
    from TTS.tts.configs.xtts_config import XttsConfig
    from TTS.tts.models.xtts import XttsAudioConfig
    from TTS.tts.models.xtts import XttsArgs
    from TTS.config.shared_configs import BaseDatasetConfig
    from TTS.config.shared_configs import BaseAudioConfig
    torch.serialization.add_safe_globals([XttsConfig, XttsAudioConfig, XttsArgs, BaseDatasetConfig, BaseAudioConfig])
except ImportError:
    pass

import torchaudio
torchaudio.load = lambda path, **kwargs: (torch.tensor(sf.read(path)[0]).unsqueeze(0).float(), sf.read(path)[1])

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model_dir = os.path.join(BASE_DIR, "Ne_Tonu")
speaker_wav = os.path.join(BASE_DIR, "sample.wav")
cache_dir = os.path.join(BASE_DIR, "cache_voices")

if not os.path.exists(cache_dir):
    os.makedirs(cache_dir)

# ==========================================
# 2. ПУТИ И ПРОЦЕССЫ
# ==========================================
APPS = {
    "браузер": r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "стим": r"C:\Program Files (x86)\Steam\steam.exe",
    "юнити": r"C:\Program Files\Unity Hub\Unity Hub.exe",
    "саундпад": r"C:\Program Files\Soundpad\Soundpad.exe",
    "компас": r"C:\Program Files\ASCON\KOMPAS-3D v24 Study\Bin\kStudy.exe",
    "печать": r"C:\Program Files\Bambu Studio\bambu-studio.exe",
    "шестерни": r"C:\Users\User\AppData\Local\Programs\FreeCAD 1.1\bin\freecad.exe",
    "блендер": r"C:\Program Files\Blender Foundation\Blender 5.2\blender-launcher.exe",
    "войсмод": r"C:\Program Files\Voicemod V3\Voicemod.exe",
    "лама": r"C:\Users\User\AppData\Local\Programs\Ollama\ollama app.exe",
    "себя": r"C:\Users\User\Desktop\JARVIS"
}

KILL_APPS = {
    "браузер": "msedge.exe", "стим": "steam.exe", "юнити": "Unity Hub.exe",
    "саундпад": "Soundpad.exe", "компас": "kStudy.exe", "печать": "bambu-studio.exe",
    "шестерни": "freecad.exe", "блендер": "blender.exe", "войсмод": "Voicemod.exe",
    "дискорд": "Discord.exe", "блокнот": "notepad.exe", "диспетчер задач": "Taskmgr.exe",
    "калькулятор": "Calculator.exe", "cmd": "cmd.exe", "командная строка": "cmd.exe"
}

# ==========================================
# 3. ФУНКЦИИ УПРАВЛЕНИЯ
# ==========================================
def set_volume(level=None, change=None):
    try:
        speakers = AudioUtilities.GetSpeakers()
        interface = speakers._dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = cast(interface, POINTER(IAudioEndpointVolume))
        
        current_vol = volume.GetMasterVolumeLevelScalar() * 100
        
        if level is not None:
            new_vol = max(0, min(100, level))
        elif change is not None:
            new_vol = max(0, min(100, current_vol + change))
        else:
            return
            
        volume.SetMasterVolumeLevelScalar(new_vol / 100, None)
        print(f"[Механика] Громкость: {int(new_vol)}%")
        return f"Устанавливаю громкость на {int(new_vol)} процентов."
    except Exception as e:
        print(f"Ошибка звука: {e}")
        return "Ошибка управления звуком."

def execute_command(cmd_tag):
    if cmd_tag == "дискорд":
        try:
            zapret_path = r"C:\Users\User\Desktop\прочее\zapret-discord-youtube-1.10.2\general (ALT)"
            os.system(f'start "" "{zapret_path}"')
            time.sleep(3)
            discord_path = r"C:\Users\User\AppData\Local\Discord"
            os.system(f'start "" "{discord_path}"')
        except Exception as e:
            print(f"Ошибка запуска Discord: {e}")
    elif cmd_tag == "моя игра":
        os.system("start steam://rungameid/108600")
    elif cmd_tag in APPS:
        path = APPS[cmd_tag]
        try:
            os.startfile(path)
        except Exception as e:
            print(f"Ошибка запуска {cmd_tag}: {e}")

def kill_process(process_name):
    try:
        subprocess.run(["taskkill", "/F", "/IM", process_name], capture_output=True)
        print(f"[Механика] Закрыт процесс: {process_name}")
    except Exception as e:
        print(f"Ошибка закрытия {process_name}: {e}")

def minimize_window_by_title(title):
    """Сворачивает окно по его заголовку"""
    try:
        windows = gw.getWindowsWithTitle(title)
        if windows:
            for win in windows:
                if not win.isMinimized:
                    win.minimize()
            print(f"[Механика] Свернуто окно: {title}")
            return True
        return False
    except Exception as e:
        print(f"Ошибка сворачивания окна {title}: {e}")
        return False

def minimize_process(process_name):
    """Сворачивает окно по имени процесса (если знаем точное имя)"""
    # Получаем все окна
    try:
        for proc in psutil.process_iter(['pid', 'name']):
            if proc.info['name'] and proc.info['name'].lower() == process_name.lower():
                # Ищем окна, принадлежащие этому процессу
                for win in gw.getAllWindows():
                    if win.title and win.visible:
                        # Проверяем, принадлежит ли окно этому процессу (по PID)
                        # В pygetwindow нет прямого доступа к PID, но можно проверить по заголовку
                        # Если это браузер, он часто называется "Новая вкладка" или "Яндекс"
                        pass
        # Если не нашли - пробуем по заголовку
        return minimize_window_by_title(title)
    except Exception as e:
        print(f"Ошибка сворачивания процесса {process_name}: {e}")
        return False

def close_all_folders():
    print("[Механика] Закрываю все папки...")
    try:
        subprocess.run("taskkill /f /im explorer.exe && start explorer.exe", shell=True)
        print("[Механика] Все папки закрыты.")
    except Exception as e:
        print(f"Ошибка закрытия папок: {e}")

def restart_network():
    print("[Механика] Перезагрузка сети...")
    try:
        os.system("ipconfig /release")
        time.sleep(5)
        os.system("ipconfig /renew")
    except Exception as e:
        print(f"Ошибка сети: {e}")

# ==========================================
# 4. ЛОГИКА ЗАЩИТЫ
# ==========================================
def cancel_shutdown_timer():
    global shutdown_blocked_until, shutdown_block_timer
    os.system("shutdown /a") 
    shutdown_blocked_until = time.time() + (10 * 60) 
    print("[Защита] Выключение отменено. Блокировка на 10 минут.")
    
    if shutdown_block_timer:
        shutdown_block_timer.cancel()
    shutdown_block_timer = threading.Timer(10 * 60, reset_shutdown_block)
    shutdown_block_timer.start()

def reset_shutdown_block():
    global shutdown_blocked_until
    shutdown_blocked_until = 0
    print("[Защита] Блокировка выключения снята.")

def is_shutdown_blocked():
    return time.time() < shutdown_blocked_until

# ==========================================
# 5. ЗАГРУЗКА МОДЕЛЕЙ
# ==========================================
print("Загрузка XTTS...")
from TTS.utils.synthesizer import Synthesizer
tts = Synthesizer(
    tts_checkpoint=model_dir, 
    tts_config_path=os.path.join(model_dir, "config.json"),
    tts_speakers_file=os.path.join(model_dir, "speakers_xtts.pth"),
    use_cuda=False
)

command_queue = []
chat_history = []

# ==========================================
# 6. ФУНКЦИИ ГОЛОСА И МОЗГА
# ==========================================
def sanitize_filename(text):
    clean_text = re.sub(r'[\\/*?:"<>|]', "_", text)
    if len(clean_text) > 100: clean_text = clean_text[:100]
    return clean_text.strip()

def get_cached_phrases():
    files = os.listdir(cache_dir)
    return [f.replace(".wav", "") for f in files if f.endswith(".wav")]

def should_save_to_cache(text):
    text_lower = text.lower()
    for word in NO_CACHE_WORDS:
        if word in text_lower:
            return False
    return True

def say(text, force_no_cache=False, is_buffer=False):
    global is_speaking
    is_speaking = True 
    
    text = text.replace("...", ".").replace("..", ".")
    text = text.replace('"', '').replace('«', '').replace('»', '')
    text = text.strip()
    if not text.endswith('.'):
        text += "."
    
    safe_name = sanitize_filename(text)
    file_path = os.path.join(cache_dir, f"{safe_name}.wav")
    
    if is_buffer:
        can_cache = True
    else:
        can_cache = should_save_to_cache(text) and not force_no_cache

    try:
        if can_cache and os.path.exists(file_path):
            audio_data, sr = sf.read(file_path)
            sd.play(audio_data, sr)
            sd.wait()
            is_speaking = False
            return

        if can_cache:
            cached_files = [f for f in os.listdir(cache_dir) if f.endswith(".wav")]
            for cached_file in cached_files:
                cached_text = cached_file.replace(".wav", "")
                if cached_text.lower() in text.lower() or text.lower() in cached_text.lower():
                    print(f"Кэш: '{cached_text}'")
                    audio_data, sr = sf.read(os.path.join(cache_dir, cached_file))
                    sd.play(audio_data, sr)
                    sd.wait()
                    is_speaking = False
                    return

        print(f"Синтез: '{text}'...")
        outputs = tts.tts_model.synthesize(
            text=text.rstrip('.'),
            speaker_wav=speaker_wav, 
            language="ru",
            config=tts.tts_model.config, 
            enable_text_splitting=False
        )
        wav = outputs["wav"]
        
        if can_cache:
            sf.write(file_path, wav, 24000)
        
        sd.play(wav, 24000)
        sd.wait()
        
    except Exception as e:
        print(f"Ошибка синтеза: {e}")
    finally:
        is_speaking = False

def think_and_say(text):
    global chat_history
    print(f"Вы: {text}")
    
    if "не выключай" in text.lower():
        cancel_shutdown_timer()
        say("Понял. Выключение отменено. Блокировка на десять минут.")
        return

    cached_phrases = get_cached_phrases()
    
    now = datetime.datetime.now()
    current_time = now.strftime("%H:%M")
    current_date = now.strftime("%d.%m.%Y")
    
    system_prompt = f"""
    Ты — Джарвис, продвинутый ИИ-ассистент. 
    Ты можешь поддерживать длинные беседы. Отвечай на вопросы развернуто, но по делу (до {MAX_WORDS} слов).
    НИКОГДА не используй многоточие и кавычки. Заканчивай мысль точкой.
    
    ВАЖНО: НЕ используй слово "сэр" в каждом предложении. 
    Ты должен СТРОГО добавлять теги действий в ответ, если тебя просят что-то сделать.

    ТЕКУЩЕЕ ВРЕМЯ (МСК): {current_time}
    ТЕКУЩАЯ ДАТА (МСК): {current_date}

    ТЕГИ ДЕЙСТВИЙ:
    - Открыть программу: [RUN:имя]
    - Закрыть процесс: [KILL:имя]
    - Свернуть (скрыть) окно: [MIN:имя] (например, [MIN:браузер], [MIN:стим])
    - Закрыть все папки: [CLOSE:ALL_FOLDERS]
    - Громкость: [VOL_UP], [VOL_DOWN], [VOL_SET:50]
    - Перезагрузить интернет: [RESTART_NET]
    - Выключить ПК: [SHUTDOWN]
    - Перезагрузить ПК: [REBOOT]

    Список RUN: браузер, стим, юнити, саундпад, компас, печать, шестерни, блендер, войсмод, лама, себя, дискорд, моя игра.
    Список KILL: браузер, стим, юнити, саундпад, компас, печать, шестерни, блендер, войсмод, дискорд, блокнот, диспетчер задач, калькулятор, cmd.
    """
    
    if cached_phrases:
        system_prompt += f"\n\nКэш фраз:\n{cached_phrases}"
    
    chat_history.append({'role': 'user', 'content': text})
    
    if len(chat_history) > 6:
        chat_history = chat_history[-6:]
        
    messages = [{'role': 'system', 'content': system_prompt}] + chat_history
    
    try:
        need_buffer = False
        for word in NO_CACHE_WORDS:
            if word in text.lower():
                need_buffer = True
                break
        
        if need_buffer:
            buffer_phrase = random.choice(BUFFER_PHRASES)
            print(f"[Буфер]: {buffer_phrase}")
            say(buffer_phrase, is_buffer=True)
        
        response = ollama.chat(model='gemma4:31b-cloud', messages=messages)
        answer = response['message']['content']
        
        # 1. Запуск
        match_run = re.search(r'\[RUN:(.*?)\]', answer)
        if match_run:
            cmd_tag = match_run.group(1).strip().lower()
            print(f"[Механика] Запускаю: {cmd_tag}")
            execute_command(cmd_tag)
            answer = re.sub(r'\[RUN:.*?\]', '', answer).strip()
            
        # 2. Закрытие
        match_kill = re.search(r'\[KILL:(.*?)\]', answer)
        if match_kill:
            kill_tag = match_kill.group(1).strip().lower()
            if kill_tag == "проводник":
                close_all_folders()
            elif kill_tag in KILL_APPS:
                kill_process(KILL_APPS[kill_tag])
            answer = re.sub(r'\[KILL:.*?\]', '', answer).strip()
            
        # 3. Свернуть (Скрыть) окно
        match_min = re.search(r'\[MIN:(.*?)\]', answer)
        if match_min:
            min_tag = match_min.group(1).strip().lower()
            if min_tag == "проводник":
                close_all_folders()
            elif min_tag in APPS or min_tag in ["браузер", "стим", "дискорд", "блокнот", "калькулятор"]:
                # Используем поиск по процессу
                if min_tag == "браузер":
                    minimize_window_by_title("Edge") # Ищем "Edge" в заголовке
                    minimize_window_by_title("Хром")
                    minimize_window_by_title("Google")
                else:
                    minimize_window_by_title(min_tag.capitalize())
            else:
                minimize_window_by_title(min_tag)
            answer = re.sub(r'\[MIN:.*?\]', '', answer).strip()

        # 4. Закрытие папок
        if "[CLOSE:ALL_FOLDERS]" in answer:
            close_all_folders()
            answer = answer.replace("[CLOSE:ALL_FOLDERS]", "").strip()

        # 5. ЗВУК
        if "[VOL_UP]" in answer:
            res = set_volume(change=10)
            answer = res if res else "Добавляю громкости."
            answer = answer.replace("[VOL_UP]", "").strip()
        if "[VOL_DOWN]" in answer:
            res = set_volume(change=-10)
            answer = res if res else "Убавляю звук."
            answer = answer.replace("[VOL_DOWN]", "").strip()
            
        match_vol = re.search(r'\[VOL_SET:(\d+)\]', answer)
        if match_vol:
            level = int(match_vol.group(1))
            res = set_volume(level=level)
            answer = res if res else f"Устанавливаю громкость на {level}."
            answer = re.sub(r'\[VOL_SET:.*?\]', '', answer).strip()

        # 6. ИНТЕРНЕТ
        if "[RESTART_NET]" in answer:
            restart_network()
            answer = answer.replace("[RESTART_NET]", "").strip()

        # 7. ПИТАНИЕ
        if "[SHUTDOWN]" in answer:
            if is_shutdown_blocked():
                answer = "Выключение заблокировано. Сначала снимите защиту."
            else:
                say("Выключаю компьютер через 30 секунд. Скажите не выключай, чтобы отменить.")
                os.system("shutdown /s /t 30")
                answer = "Выключаю через 30 секунд."
            
        if "[REBOOT]" in answer:
            if is_shutdown_blocked():
                answer = "Перезагрузка заблокирована. Сначала снимите защиту."
            else:
                say("Перезагружаю компьютер через 30 секунд.")
                os.system("shutdown /r /t 30")
                answer = "Перезагружаю через 30 секунд."
        
        chat_history.append({'role': 'assistant', 'content': answer})
        
        words = answer.split()
        if len(words) > MAX_WORDS:
            answer = " ".join(words[:MAX_WORDS]).rstrip('.,!?') + "."
        
        answer = answer.replace("...", ".").replace("..", ".")
            
        say(answer)
    except Exception as e:
        print(f"Ошибка связи с мозгом: {e}")

# ==========================================
# 7. УШИ (GOOGLE API)
# ==========================================
def listening_loop():
    global is_speaking
    print("[Уши] Микрофон активен. Жду 'Джарвис'...")
    
    recognizer = sr.Recognizer()
    recognizer.energy_threshold = 300 
    recognizer.dynamic_energy_threshold = True
    recognizer.pause_threshold = 1.5 
    
    microphone = sr.Microphone()

    with microphone as source:
        recognizer.adjust_for_ambient_noise(source, duration=1)
        
        while True:
            try:
                if is_speaking:
                    time.sleep(0.1)
                    continue
                    
                audio = recognizer.listen(source, timeout=None, phrase_time_limit=30)
                
                if is_speaking:
                    continue
                
                text = recognizer.recognize_google(audio, language="ru-RU")
                print(f"\n[Услышано]: '{text}'")
                
                if not text: continue

                if "джарвис" in text.lower():
                    command = text.lower().replace("джарвис", "").strip()
                    command = re.sub(r'^[^\w\s]+', '', command).strip()
                    
                    if "выход" in command or "пока" in command:
                        print("Завершаю работу.")
                        os._exit(0)
                        
                    if command:
                        if is_speaking:
                            command_queue.append(command)
                        else:
                            threading.Thread(target=think_and_say, args=(command,)).start()
                    else:
                        threading.Thread(target=say, args=("Слушаю.",)).start()

            except sr.UnknownValueError:
                pass 
            except sr.RequestError as e:
                print(f"Ошибка сети/Google API: {e}")
            except Exception as e:
                pass

# ==========================================
# 8. ЗАПУСК
# ==========================================
if __name__ == "__main__":
    say("Здравствуйте, сэр. Система актививна")
    
    listen_thread = threading.Thread(target=listening_loop, daemon=True)
    listen_thread.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nВыключение...")