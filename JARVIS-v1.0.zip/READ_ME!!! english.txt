hi!!!

---

# JARVIS — Local AI Voice Assistant

This project is a fully free, local-first voice assistant that clones your voice (via XTTS), controls PC applications, manages volume, and maintains conversations (via Ollama). 

## 🚀 Installation

### Step 1: What to Download
1. **Python 3.10** (Must be exactly 3.10; other versions will not work). Download from the official website (make sure to check `Add Python to PATH` during installation).
2. **Ollama** (The brain). Download from [ollama.com](https://ollama.com). After installing, open the terminal and type `ollama signin` to activate the cloud model.
3. **XTTS Voice Model.** GitHub does not allow files larger than 100 MB, so you must download the `Ne_Tonu` folder (XTTS-v2 model) from this link: `[INSERT YOUR GOOGLE DRIVE / YANDEX DISK LINK]` and place it in the project root.
4. **Your Voice.** Record a 5-10 second sample of your voice in `.wav` format, name it `sample.wav`, and place it in the project root.

### Step 2: What to Install via Terminal
Open Command Prompt (cmd) and run these commands one by one:

```bash
py -3.10 -m pip install torch torchaudio --index-url https://pypi.org/simple/
py -3.10 -m pip install TTS sounddevice soundfile SpeechRecognition pyaudio
py -3.10 -m pip install ollama numpy pygetwindow pyautogui psutil pycaw comtypes
Step 3: Run
Double-click Запустить_Джарвиса.bat (or type py -3.10 jarvis_main.py in the terminal).
Say: "Jarvis, how are you?".

⚙️ Customization
Open jarvis_main.py in any code editor (like VS Code or Notepad).

1. Adding Your Own Apps
Find the APPS dictionary at the top of the code. To add your program, append a line like this:

python
"notepad": r"C:\Windows\System32\notepad.exe",
Important: Always add a comma at the end of the line!!!!!!
Then, add [RUN:notepad] to the system prompt (in the system_prompt variable) so the AI knows about this command.

You can also find the list of processes to close in the KILL_APPS dictionary (search for the words "ПУТИ И ПРОЦЕССЫ" using Ctrl+F). Change the names or synonyms as you wish — the AI will understand.

2. Changing the AI Voice
You can use absolutely any character's voice (from your own voice to a sperm whale).

Create a WAV file from an MP3 (for example, here: https://convertio.co/mp3-wav/).

Rename your WAV file to sample.wav and place it in the project folder (MUST replace the old file!).

To hear the new voice, delete all MP3 files from the cache_voices folder (this clears the cache).

3. Changing the Language to English
By default, the assistant is set to Russian. To switch it to English, change these 3 lines in jarvis_main.py:

In listening_loop, find language="ru-RU" and change it to language="en-US".

In the say function, find language="ru" and change it to language="en".

In the system_prompt variable, translate the instructions and examples into English (e.g., "You are Jarvis, an AI assistant. Answer briefly.").

☕ Support the Author
This project is 100% free and open-source. If it helped you and you want to say thanks, you can buy me a coffee. I am also developing a tactical strategy game, which will be released in about 6-12 months. If you like the idea of the game, I will always be waiting for you on Boosty (.- | - .- -.- ...- . | .--. .- ... .... .- .-.. -.- ..). Thank you for downloading Jarvis!!!

🌎 Boosty (International): https://boosty.to/morze_war